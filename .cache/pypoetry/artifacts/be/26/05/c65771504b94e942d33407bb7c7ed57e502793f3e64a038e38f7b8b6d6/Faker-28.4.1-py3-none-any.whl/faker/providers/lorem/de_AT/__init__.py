from ..de_DE import Provider as GermanProvider


class Provider(GermanProvider):
    """Implement lorem provider for ``de_DE`` locale.
    Using the same as in ```de_DE```.
    """

    pass
